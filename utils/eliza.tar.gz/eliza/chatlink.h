
#ifndef __CHATLINK_H__
#define __CHATLINK_H__

extern void startchat( char *filename );
extern char *dochat( char *talker, char *message, char *target );
extern void endchat( void );

#endif
