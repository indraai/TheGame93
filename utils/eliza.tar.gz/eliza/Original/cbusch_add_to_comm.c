
This line needs to be added to comm.c which contains main()

/*add at line 338 which is the beginning of main*/
    startchat("chat.data");
