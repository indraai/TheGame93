Chris Busch

Although I wont detail what I did to this file.  I will tell you that your
NPCs will not be able to initiate attacks on PCs unless some of the
safeguards are removed.

