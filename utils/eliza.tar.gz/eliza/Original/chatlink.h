

void startchat(char* filename);
char* dochat(char* talker,char* message,char* target);
