The following lines must be added to the end of the merc.h file.
You will need to create a chat directory in your src directory.
/*cbusch was here*/
#include <dlfcn.h> /*this might not be necessary for your UNIX machine.*/
#include "chat/chatlink.h"

