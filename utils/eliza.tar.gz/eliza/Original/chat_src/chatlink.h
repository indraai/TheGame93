

void startchat(char*);
char* dochat(char*);
